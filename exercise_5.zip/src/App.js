import './App.css';
import React, {useState, useEffect} from 'react';

function App() {
     return (
      <div className="App">
        <h2>Hello React World!</h2>
      </div>
    )
}
export default App;