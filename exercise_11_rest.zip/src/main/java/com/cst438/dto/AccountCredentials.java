package com.cst438.dto;

public record AccountCredentials(String username, String password) {
	
}
