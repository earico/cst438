package com.cst438.dto;


public record MultiplyResult (int id, String alias, int factorA, int factorB, int attempt, int answer, boolean correct) {
};
